export class MissionSkill{
  id:number=0;
  skillName:string='';
  status:string='';
}
