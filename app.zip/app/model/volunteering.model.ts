export class VolunteeringHours{
  id:number=0;
  userId:number=0;
  missionId:number=0;
  missionName:string='';
  dateVolunteered:any;
  hours:string='';
  minutes:string='';
  message:string='';
}

export class VolunteeringGoals{
  id:number=0;
  userId:number=0;
  missionId:number=0;
  missionName:string='';
  date:any;
  action:number=0;
  message:string='';
}
